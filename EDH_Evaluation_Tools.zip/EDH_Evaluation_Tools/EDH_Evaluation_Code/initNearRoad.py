#Script Name:                   initNearRoad.py
#Corresponding Script Tool:     EDH Streams Initiating Near Roads
#Purpose:                       To flag EDH flow lines that begin near roads.
#Methodology:                   Headwater points are created. "Near" proximity tool used to detect roads near the headwater points.
#                               See "HwProximityToRoad" field in EDH_Lines
#Author:                        Lucian Stewart, North Carolina State University, 04/05/2020

#import modules
import sys, os
thisPath = os.path.abspath(__file__)
thisDir = os.path.dirname(thisPath)
configPath = os.path.join(thisDir, "config")
sys.path.append(configPath)
import HydroAssessmentClass, GeneralFunctions, ResultsReporting
reload(HydroAssessmentClass)
reload(GeneralFunctions)
reload(ResultsReporting)



#get arguments
edhWS = sys.argv[1]
roadsFc = sys.argv[2]
flagDist = float(sys.argv[3])
writeReport = sys.argv[4]
removeTemp = sys.argv[5]

#run analysis
myEvalGdb = os.path.join(edhWS, "EDH_Evaluation.gdb")
myTempWS = os.path.join(edhWS, "EDH_Assessment_TempDir")
myEDHLines = os.path.join(myEvalGdb, "EDH_Lines")
myFormattedEDH = HydroAssessmentClass.FormattedHydroData(myEvalGdb, myTempWS, myEDHLines)
myProj = GeneralFunctions.getProjection(myEDHLines)
myUnit = GeneralFunctions.translateLinearUnit(myProj.linearUnitName)
myDistUnit = str(flagDist) + " " + myUnit
GeneralFunctions.messageUser("Flagging flow lines with headwater initiation " + myDistUnit + " from roads.")
myFormattedEDH.detect_edhInitiationNearRoads(roadsFc, flagDist)

#write report
if writeReport == "true":
    myReport = ResultsReporting.EvalReport(edhWS, configPath)
    myReport.report_initNearRoad(myDistUnit)

if removeTemp == "true":
    GeneralFunctions.cleanTempGdbs(myTempWS)
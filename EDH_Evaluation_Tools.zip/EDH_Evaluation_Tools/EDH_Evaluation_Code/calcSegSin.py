#Script Name:                   calcSegSin.py
#Corresponding Script Tool:     Calculate Segmented Sinuosity
#Purpose:                       To calculate sinuosity along hydro lines at user defined interval
#Methodology:                   Divides input lines at specified distance.  Creates straight-line segment from start to end point.
#                               Calculates sinuosity by dividing segment length by straight-line length.
#Author:                        Lucian Stewart, North Carolina State University, 04/05/2020

#import modules
import sys, os, arcpy
thisPath = os.path.abspath(__file__)
thisDir = os.path.dirname(thisPath)
configPath = os.path.join(thisDir, "config")
sys.path.append(configPath)
import HydroAssessmentClass, GeneralFunctions, ResultsReporting
reload(HydroAssessmentClass)
reload(GeneralFunctions)
reload(ResultsReporting)



#get arguments
edhWS = sys.argv[1]
segDist = float(sys.argv[2])
edhCalc = sys.argv[3]
nhdCalc = sys.argv[4]
writeReport = sys.argv[5]
removeTemp = sys.argv[6]


#run analysis
myEvalGdb = os.path.join(edhWS, "EDH_Evaluation.gdb")
myTempWS = os.path.join(edhWS, "EDH_Assessment_TempDir")
myEDHLines = os.path.join(myEvalGdb, "EDH_Lines")
myNHDLines = os.path.join(myEvalGdb, "NHD_Lines")
myFormattedEDH = HydroAssessmentClass.FormattedHydroData(myEvalGdb, myTempWS, myEDHLines, myNHDLines)

myProj = GeneralFunctions.getProjection(myEDHLines)
myUnit = GeneralFunctions.translateLinearUnit(myProj.linearUnitName)
myReport = ResultsReporting.EvalReport(edhWS, configPath)
segDistAndUnit = str(segDist) + " " + myUnit
status = "RUNNING"

if edhCalc == "true":
    myFormattedEDH.calc_segmentedSinuosity(segDist, "EDH")
    if writeReport == "true":
        myReport.report_calcSegSin(segDistAndUnit,"EDH")

if nhdCalc == "true":
    if arcpy.Exists(myNHDLines):
        myFormattedEDH.calc_segmentedSinuosity(segDist, "NHD")
        if writeReport == "true":
            myReport.report_calcSegSin(segDistAndUnit,"NHD")
    else:
        GeneralFunctions.messageUser("\t Evaluation GDB is missing NHD Lines. You will need to run the 'Import NHD Lines Post-Eval Environment Set-Up' tool before attempting this tool on NHD Lines.")
        status = "FAILED"

if status == "RUNNING":
    if removeTemp == "true":
        GeneralFunctions.cleanTempGdbs(myTempWS)

    if writeReport == "true":
        reportFile = os.path.join(edhWS, "EDH_EvalReport.txt")
        os.startfile(reportFile)
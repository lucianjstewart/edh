#Script Name:                   compGridSegSin.py
#Corresponding Script Tool:     Compare NHD/EDH Segmented Sinuosity within Grid
#Purpose:                       To gauge the improvement of sinusoity within grid cells of user specified size.
#Methodology:                   Creates fishnet grid encompassing EDH_Lines, calculates segmented sinuosity for NHD or EDH lines (if not already done).
#                               Creates mean of segmented sinusoity within each grid cell for EDH and NHD.  Subtracts them to gauge immprovement
#                               See " " field in DPA_Grid
#Author:                        Lucian Stewart, North Carolina State University, 04/05/2020

#import modules
import sys, os, arcpy
thisPath = os.path.abspath(__file__)
thisDir = os.path.dirname(thisPath)
configPath = os.path.join(thisDir, "config")
sys.path.append(configPath)
import HydroAssessmentClass, GeneralFunctions, ResultsReporting
reload(HydroAssessmentClass)
reload(GeneralFunctions)
reload(ResultsReporting)



#get arguments
edhWS = sys.argv[1]
gridSize = float(sys.argv[2])
writeReport = sys.argv[3]
removeTemp = sys.argv[4]


#run analysis
myEvalGdb = os.path.join(edhWS, "EDH_Evaluation.gdb")
myTempWS = os.path.join(edhWS, "EDH_Assessment_TempDir")
myEDHLines = os.path.join(myEvalGdb, "EDH_Lines")
myNHDLines = os.path.join(myEvalGdb, "NHD_Lines")
myFormattedEDH = HydroAssessmentClass.FormattedHydroData(myEvalGdb, myTempWS, myEDHLines, myNHDLines)
myProj = GeneralFunctions.getProjection(myEDHLines)
myUnit = GeneralFunctions.translateLinearUnit(myProj.linearUnitName)
grdUnit = str(gridSize) + " " + myUnit

edhSS = os.path.join(myEvalGdb, "EDH_SS_Segments")
nhdSS = os.path.join(myEvalGdb, "NHD_SS_Segments")
status = "RUNNING"

if arcpy.Exists(edhSS) and arcpy.Exists(nhdSS):
    GeneralFunctions.messageUser("Calculating EDH Grid Segmented Sinuosity. Grid Size: " + grdUnit)
    myFormattedEDH.calc_gridSegSinuosity(gridSize, "EDH")

    GeneralFunctions.messageUser("Calculating NHD Grid Segmented Sinuosity. Grid Size: " + grdUnit)
    myFormattedEDH.calc_gridSegSinuosity(gridSize, "NHD")

    GeneralFunctions.messageUser("Comparing Gridded Segmented Sinuosity")
    myFormattedEDH.compare_gridSegSinuosity()
else:
    GeneralFunctions.messageUser("Analysis Not Performed.  Segmented Sinuosity for both NHD and EDH must be calculated prior to running this tool.")
    status = "FAILED"


#write report
if status == "RUNNING":
    if writeReport == "true":
        myReport = ResultsReporting.EvalReport(edhWS, configPath)
        myReport.report_compGridSegSin(grdUnit)

    if removeTemp == "true":
        GeneralFunctions.cleanTempGdbs(myTempWS)
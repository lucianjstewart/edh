#Script Name:                   matchNHDtoEDH.py
#Corresponding Script Tool:     Match NHD Streams to EDH Counterparts
#Purpose:                       To identify NHD stream line features that were ommitted from the EDH Dataset
#Methodology:                   Finds EDH counterpart stream features for each NHD feature by using NHD vertex to EDH line proximity tools (Near Geoprocessing Tool)
#                               By default, a match is qualified when 3 vertices from the same NHD line find the same EDH line feature within 50 feet.
#                               NHD streams with no match will be flagged (See EDH_LineIDs and MatchFlag fields appended to NHD_Lines)
#Author:                        Lucian Stewart, North Carolina State University, 04/05/2020

#import modules
import sys, os, arcpy
thisPath = os.path.abspath(__file__)
thisDir = os.path.dirname(thisPath)
configPath = os.path.join(thisDir, "config")
sys.path.append(configPath)
import HydroAssessmentClass, GeneralFunctions, ResultsReporting
reload(HydroAssessmentClass)
reload(GeneralFunctions)
reload(ResultsReporting)



#get arguments
edhWS = sys.argv[1]
candDist = float(sys.argv[2])
qualVCount = int(sys.argv[3])
writeReport = sys.argv[4]
removeTemp = sys.argv[5]


#run analysis
myEvalGdb = os.path.join(edhWS, "EDH_Evaluation.gdb")
myTempWS = os.path.join(edhWS, "EDH_Assessment_TempDir")
myEDHLines = os.path.join(myEvalGdb, "EDH_Lines")
myNHDLines = os.path.join(myEvalGdb, "NHD_Lines")

if not(arcpy.Exists(myNHDLines)):
    GeneralFunctions.messageUser("\t Evaluation GDB is missing EDH Lines. You will need to run the 'Import NHD Lines Post-Eval Environment Set-Up' tool before attempting this tool.")
else:
    myFormattedEDH = HydroAssessmentClass.FormattedHydroData(myEvalGdb, myTempWS, myEDHLines, myNHDLines)
    myFormattedEDH.match_NHDstreams(candDist, qualVCount)
    myProj = GeneralFunctions.getProjection(myEDHLines)
    myUnit = GeneralFunctions.translateLinearUnit(myProj.linearUnitName)
    myDistUnit = str(candDist) + " " + myUnit

    #write report
    if writeReport == "true":
        myProj = GeneralFunctions.getProjection(myEDHLines)
        myUnit = GeneralFunctions.translateLinearUnit(myProj.linearUnitName)
        myReport = ResultsReporting.EvalReport(edhWS, configPath)
        myReport.report_matchNHDtoEDH(qualVCount, myDistUnit)

    if removeTemp == "true":
        GeneralFunctions.cleanTempGdbs(myTempWS)
#Script Name:                   createEDHevalEnv.py
#Corresponding Script Tool:     Create EDH Evaluation Environment
#Purpose:                       To create geodatabase and temporary workspace for EDH Evaluation Tools
#Methodology:                   Copies user EDH Lines, NHD Lines, and DPA file to a geodatabase in the user's input parent folder (EDH_Evaluation.gdb).
#                               Projects all information to the same projection as the input EDH lines.
#                               Creates "EDH_Assessment_TempDir" folder to store temporary analysis datasets.
#Author:                        Lucian Stewart, North Carolina State University, 04/05/2020

#import modules
import sys, os
thisPath = os.path.abspath(__file__)
thisDir = os.path.dirname(thisPath)
configPath = os.path.join(thisDir, "config")
sys.path.append(configPath)
import HydroAssessmentClass, GeneralFunctions
reload(HydroAssessmentClass)
reload(GeneralFunctions)

#get arguments
outWS = sys.argv[1]
myEDH = sys.argv[2]
myDPA = sys.argv[3]
myNHD = sys.argv[4]

#get EDH projection
myRef = GeneralFunctions.getProjection(myEDH)

#create EDH evaluation environment
myEDH_eval = HydroAssessmentClass.InputHydroData(myEDH, myRef, outWS, myNHD)
myEDH_eval.assessmentPreprocess(myDPA)
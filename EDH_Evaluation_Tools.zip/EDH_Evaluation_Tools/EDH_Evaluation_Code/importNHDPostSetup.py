#Script Name:                   importNHDPostSetup.py
#Corresponding Script Tool:     Import NHD Lines Post-Eval Environment Set-Up
#Purpose:                       To timport NHD Lines into EDH_Evaluation.gdb if user does not initially import them with Create EDH Evaluation Environment.
#Methodology:                   Projects NHD lines (if needed), clips them to DPA, and stores them in EDH_Evaluation.gdb
#Author:                        Lucian Stewart, North Carolina State University, 04/05/2020

import sys, os, arcpy
thisPath = os.path.abspath(__file__)
thisDir = os.path.dirname(thisPath)
configPath = os.path.join(thisDir, "config")
sys.path.append(configPath)
import GeneralFunctions
reload(GeneralFunctions)

#get arguments
edhWS = sys.argv[1]
nhdLines = sys.argv[2]

GeneralFunctions.importNHD(nhdLines,edhWS)
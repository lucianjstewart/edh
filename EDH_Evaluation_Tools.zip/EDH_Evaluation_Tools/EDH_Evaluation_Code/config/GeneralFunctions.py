#Script Name:                   General functions.py
#Purpose:                       To support general operations of EDH Evaluation tools.
#Author:                        Lucian Stewart, North Carolina State University, 04/05/2020

import arcpy, os, shutil

def getProjection(dataset):
    '''Returns the projection of the input dataset.'''
    desc = arcpy.Describe(dataset)
    myRef = desc.spatialReference

    return myRef

def getExtent(dataset):
    '''Returns the extent of the input dataset.'''
    desc = arcpy.Describe(dataset)
    myExt = desc.extent

    return myExt

def messageUser(message):
    '''Messages the user in arcpy environment and python console environment.'''
    print(message)
    arcpy.AddMessage(message)

def translateLinearUnit(origUnit):
    '''Returns the projection unit in format suitable for arcpy tools.'''
    transUnit = ""
    if origUnit.upper() == 'METER':
        transUnit = "METERS"
    elif "Foot" in origUnit or "Feet" in origUnit:
        transUnit = "FEET"

    return transUnit

def detectStraightSegs(lineFeature, segDist, spatialRef):
    '''Detects straight segments within segDist.'''
    #intial variables
    searchLine = lineFeature[1]
    ang = 0.0
    lastAng = 1000.0
    sumDist = 0.0
    segFlags = 0
    stLines = []

    #loop through line parts (accounts for multi-part features)
    for part in searchLine:

        ptIt = 0
        ptArray = arcpy.Array()
        ptList = []
        lnArray = []

        #loop through vertices in line part
        for pt in part[1:(len(part)-1)]:

            #skip the first point since there isn't a previous segment
            if ptIt >=1:

                #get previous point
                lastPt = part[ptIt - 1]
                lastPtGeo = arcpy.PointGeometry(lastPt, spatialRef)

                #get this point
                thisPtGeo = arcpy.PointGeometry(pt, spatialRef)

                #get angle/distance to last point
                angDist = thisPtGeo.angleAndDistanceTo(lastPtGeo, "PLANAR")
                ang = round(angDist[0],2)
                dist = angDist[1]

                #if the previous angle is the same as this angle, the segment is straight
                if ang == lastAng:

                    #add distances, add points to point array
                    sumDist+=dist
                    lastLastPt = part[ptIt - 2]
                    if lastLastPt not in ptList:
                        ptList.append(lastLastPt)
                    if lastPt not in ptList:
                        ptList.append(lastPt)
                    if pt not in ptList:
                        ptList.append(pt)

                #else, the line has changed direction
                else:
                    #if the point array has more than one point, build a line
                    if len(ptList) >= 2:
                        #build  2 vertex segment
                        bldArray = arcpy.Array()
                        bldArray.add(ptList[0])
                        bldArray.add(ptList[len(ptList)-1])
                        bldLine = arcpy.Array(bldArray)
                        stLine = arcpy.Polyline(bldLine,spatialRef)
                        bldArray.removeAll

                        #if the line length is longer than the specified distance, append it to the line list
                        if stLine.length > segDist:
                            ptArray.removeAll()
                            ptList = []
                            lnArray.append(stLine)
                            segFlags +=1

                    sumDist = 0.0

                    #if the pt list contains points, clean it out for the next line
                    if len(ptList) >0:
                        ptList = []

                lastAng = ang
            ptIt+=1

        if len(lnArray) > 0:
            for ln in lnArray:
                stLines.append(ln)

    return segFlags, stLines

def cleanTempGdbs(tempWS):
    '''Removes all feature classes from temporary analysis geodatabases.'''
    listTempDir = os.listdir(tempWS)
    gdbList = [gdb for gdb in listTempDir if gdb.endswith("gdb")]

    for gdb in gdbList:
        gdbLoc = os.path.join(tempWS, gdb)
        arcpy.env.workspace = gdbLoc

        #delete feature classes
        fcList = arcpy.ListFeatureClasses("*")
        for fc in fcList:
            fcPath = os.path.join(gdbLoc, fc)
            arcpy.Delete_management(fcPath)

        #delete tables
        tableList = arcpy.ListTables("*")
        for table in tableList:
            tabPath = os.path.join(gdbLoc, table)
            arcpy.Delete_management(tabPath)

def importNHD(inFeatures, outWS):
    '''Imports NHD lines into EDH_Evaluation.gdb.'''
    evalGDB = os.path.join(outWS, "EDH_Evaluation.gdb")
    tempGDB1 = os.path.join(outWS, "EDH_Assessment_TempDir\\tempGDB1.gdb")
    tempProjNHD = os.path.join(tempGDB1, "NHD_ProjectedLines")
    destNHD_Lines = os.path.join(evalGDB, "NHD_Lines")
    dpa = os.path.join(evalGDB, "DPA")
    messageUser("\t Calculating NHD ID Field")
    #add original OBJECTID field to lines so that all assessment fields can be rejoined
    arcpy.AddField_management(inFeatures, "OrigNHD_ID", "LONG")
    #calculate OrigOBJECTID for NHD Lines
    arcpy.CalculateField_management(inFeatures, "OrigNHD_ID", expression="!OBJECTID!", expression_type="PYTHON_9.3", code_block="")

    #project
    nhdProj = getProjection(inFeatures)
    edhLines = os.path.join(evalGDB, "EDH_Lines")
    edhProj = getProjection(edhLines)

    #make temp copy to accomodate network dataset inputs
    tempCopyNHD = os.path.join(tempGDB1, "CopyOrigNHD")
    arcpy.CopyFeatures_management(inFeatures,tempCopyNHD)

    if nhdProj.name != edhProj.name:
        messageUser("\t Projecting NHD Lines")
        arcpy.Project_management(tempCopyNHD, tempProjNHD, edhProj)
        messageUser("\t Clipping NHD Lines to DPA")
        arcpy.Clip_analysis(tempProjNHD, dpa, destNHD_Lines)
    else:
        messageUser("\t Clipping NHD Lines to DPA")
        arcpy.Clip_analysis(tempCopyNHD, dpa, destNHD_Lines)

#Script Name:                   HydroAssessmentClass.py
#Purpose:                       To format and analyze Elevation Derived Hydrography (EDH) Datasets.
#Author:                        Lucian Stewart, North Carolina State University, 04/05/2020

import arcpy, os, GeneralFunctions

class InputHydroData:
    '''InputHydroData contains information relevant to user-supplied, raw hydro data.'''
    def __init__(self, edhLines, spatialRef, outputWS, nhdLines = ""):
        self.edhLines = edhLines
        self.spatialRef = spatialRef
        self.outputWS = outputWS
        self.nhdLines = nhdLines

    def assessmentPreprocess(self,inDPA=""):
        '''Creates EDH evaluation environment so that subsequent tools can be run.'''

        #create eval geodatabase
        GeneralFunctions.messageUser("\t Creating eval geodatabase")
        evalGdb = os.path.join(self.outputWS, "EDH_Evaluation.gdb")
        try:
            arcpy.CreateFileGDB_management(self.outputWS, "EDH_Evaluation.gdb")
        except:
            GeneralFunctions.messageUser("\t EDH_Evaluation geodatabase already exists. Please rename it or remove it from output directory")

        #create temp directories
        GeneralFunctions.messageUser("\t Creating temporary workspace")
        try:
            tempDir = os.path.join(self.outputWS, "EDH_Assessment_TempDir")

            #tempGDB paths
            tempGDB1 = os.path.join(tempDir, "tempGDB1.gdb")
            tempGDB2 = os.path.join(tempDir, "tempGDB2.gdb")
            tempGDB3 = os.path.join(tempDir, "tempGDB3.gdb")

            #create tempGDBs
            os.mkdir(tempDir)
            arcpy.CreateFileGDB_management(tempDir, "tempGDB1.gdb")
            arcpy.CreateFileGDB_management(tempDir, "tempGDB2.gdb")
            arcpy.CreateFileGDB_management(tempDir, "tempGDB3.gdb")
        except:
            GeneralFunctions.messageUser("\t EDH_Assessment_TempDir already exists. Please rename it or remove it from output directory.")


        #manage DPA polygon if provided, if not, create one
        dpaDest = os.path.join(evalGdb, "DPA")
        if inDPA != '#':
            GeneralFunctions.messageUser("\t Copying DPA")
            dpaProj = GeneralFunctions.getProjection(inDPA)

            #copy DPA to eval geodatabase, project it if needed
            if self.spatialRef.name == dpaProj.name:
                arcpy.CopyFeatures_management(inDPA, dpaDest)
            else:
                arcpy.Project_management(inDPA, dpaDest, self.spatialRef)
        else:
            GeneralFunctions.messageUser("\t Creating DPA")
            arcpy.MinimumBoundingGeometry_management(self.edhLines, dpaDest, geometry_type="ENVELOPE", group_option="ALL", group_field="", mbg_fields_option="NO_MBG_FIELDS")


        #add original OBJECTID field to lines so that all assessment fields can be rejoined
        GeneralFunctions.messageUser("\t Calculating EDH ID Field")
        arcpy.AddField_management(self.edhLines, "OrigEDH_ID", "LONG")
        #calculate OrigOBJECTID for EDH Lines
        arcpy.CalculateField_management(self.edhLines, "OrigEDH_ID", expression="!OBJECTID!", expression_type="PYTHON_9.3", code_block="")

        #copy/project input data into gdb
        GeneralFunctions.messageUser("\t Copying in EDH Lines")
        destEDH_Lines = os.path.join(evalGdb, "EDH_Lines")
        arcpy.CopyFeatures_management(self.edhLines, destEDH_Lines)

        #import NHD if lines are provided by user
        if self.nhdLines != "#":
            GeneralFunctions.importNHD(self.nhdLines, self.outputWS)
        else:
            GeneralFunctions.messageUser("\t NHD Lines were not provided by user")

        GeneralFunctions.messageUser("\t Evaluation GDB and Temp Workspace Ready for Analysis")

        return evalGdb, tempDir


class FormattedHydroData:
    '''FormattedHydroData contains information and tools relevant to formatted EDH environment.'''
    def __init__(self, evalGdb, tempDir, edhLines, nhdLines = ""):
        self.evalGdb = evalGdb
        self.tempDir = tempDir
        self.edhLines = edhLines
        self.nhdLines = nhdLines


    def match_NHDstreams(self, matchDist = 50, vMatch = 3):
        '''Matches NHD streams to EDH streams using proximity distance (matchDist) and vertex count within distance.'''

        arcpy.env.workspace = self.evalGdb
        arcpy.env.overwriteOutput = True
        myProj = GeneralFunctions.getProjection(self.edhLines)

        #get temp gdb
        inWS = os.path.dirname(self.evalGdb)
        tempGDB1 = os.path.join(self.tempDir, "tempGDB1.gdb")

        #create NHD_Verts
        GeneralFunctions.messageUser("\t Creating NHD Vertex Points")
        NHD_Verts = os.path.join(tempGDB1, "NHD_Verts")
        arcpy.FeatureVerticesToPoints_management(self.nhdLines,NHD_Verts)

        #find nearby EDH Lines for each NHD vertex
        GeneralFunctions.messageUser("\t Determining nearby EDH Lines")
        myMatchUnit = GeneralFunctions.translateLinearUnit(myProj.linearUnitName)
        matchSearch = str(matchDist) + " " + myMatchUnit
        arcpy.Near_analysis(NHD_Verts, self.edhLines, search_radius=matchSearch, location="NO_LOCATION", angle="NO_ANGLE", method="PLANAR")

        #select matched vertices
        GeneralFunctions.messageUser("\t Removing unmatched vertices")
        matchFilter = "NEAR_FID <> -1"
        matchedVerts = os.path.join(tempGDB1, "NHD_Verts_matched")
        arcpy.Select_analysis(NHD_Verts,matchedVerts, matchFilter)

        #add fields
        GeneralFunctions.messageUser("\t Adding fields")
        arcpy.AddField_management(self.nhdLines,"EDH_LineIDs", "TEXT", field_length = 500)
        arcpy.AddField_management(self.nhdLines,"MatchFlag", "SHORT")
        arcpy.AddField_management(matchedVerts,"MatchCandidate", "TEXT")

        #calculate field
        GeneralFunctions.messageUser("\t Caclulating match field")
        MatchCandidate_expression = 'str(!ORIG_FID!) + "|" + str(!NEAR_FID!)'
        arcpy.CalculateField_management(matchedVerts, "MatchCandidate", expression=MatchCandidate_expression,expression_type="PYTHON_9.3", code_block="")

        #Count match candidates
        GeneralFunctions.messageUser("\t Qualifying match candidates")
        matchVertTable = os.path.join(tempGDB1, "NHD_MatchedVerts")
        arcpy.Statistics_analysis(matchedVerts, matchVertTable, statistics_fields="MatchCandidate COUNT", case_field="MatchCandidate")

        #Select qualified matches
        GeneralFunctions.messageUser("\t Selecting qualified matches")
        qmatchVertTable = os.path.join(tempGDB1, "NHD_QMatchedVerts")
        qSelect_expression = 'FREQUENCY >= ' + str(vMatch)
        arcpy.TableSelect_analysis(matchVertTable, qmatchVertTable, qSelect_expression)

        #build dictionary of matches to account for multiple EDH lines matching the same NHD line
        GeneralFunctions.messageUser("\t Building EDH/NHD Dictionary")
        qVertsCursor = arcpy.da.SearchCursor(qmatchVertTable, ["MatchCandidate"])
        matchDict = {}
        edhMList = []
        for qvert in qVertsCursor:
            matchCand = qvert[0]
            nhdID = str(matchCand.split("|")[0])
            edhID = str(matchCand.split("|")[1])
            edhMList.append(edhID)

            if nhdID not in matchDict.keys():
                matchDict[nhdID] = edhID
            else:
                matchDict[nhdID] = matchDict[nhdID] + "|" + edhID


        #select EDH lines that matched
        edhMQuery = "OBJECTID IN (" + ",".join(edhMList) + ")"

        #build EDH FCode Dictionary
        edhMCursor = arcpy.da.SearchCursor(self.edhLines, ["OBJECTID", "FCode"], where_clause = edhMQuery)
        edhFCdict = {}
        for edh in edhMCursor:
            edhFCdict[str(edh[0])] = str(edh[1])


        #update NHD Lines with EDH lines
        GeneralFunctions.messageUser("\t Updating NHD Lines with matched EDH features")
        nhdUCursor = arcpy.da.UpdateCursor(self.nhdLines, ["OBJECTID", "EDH_LineIDs", "MatchFlag", "FCode"])

        for nhd in nhdUCursor:
            nhdOBID = str(nhd[0])
            nhdFCode = str(nhd[3])
            flgCode = 0

            if nhdOBID in matchDict.keys():
                #get EDH Ids, write to EDH_LineIDs Field
                edhIDs = matchDict[nhdOBID]
                nhd[1] = edhIDs

                #get fcodes of all matched EDH Lines
                if "|" in edhIDs:
                    edhList = edhIDs.split("|")
                else:
                    edhList =[edhIDs]

                for edhID in edhList:
                    edhIDFcode = edhFCdict[edhID]

                    #flag non APs that matched with APs
                    if edhIDFcode == '55800' and nhdFCode <> '55800':
                        flgCode = 3
                        break

                    #flag APs that matched with non-APs
                    elif nhdFCode == '55800' and edhIDFcode <> '55800':
                        flgCode = 2
                        break

                nhd[2] = flgCode

            else:
                nhd[1] = "NO EDH FOUND WITHIN " + matchSearch
                nhd[2] = 1

            nhdUCursor.updateRow(nhd)


    def calc_segmentedSinuosity(self, segDist, nhdOrEdh = "EDH"):
        '''Calculates segmented sinuosity for segments along lines in featureClass, calculates weighted average segmented sinuosity back to line feature class'''

        #get data locations, build feature class names, get projection
        GeneralFunctions.messageUser("\t Building necessary feature classes for segmented sinuosity calculations")
        if nhdOrEdh.upper() == "EDH":
            inLines = self.edhLines
        elif nhdOrEdh.upper() == "NHD":
            inLines = self.nhdLines
        else:
            GeneralFunctions.messageUser("\t You must provide either NHD or EDH lines for this function")

        tempGdb1 = os.path.join(self.tempDir, "tempGDB1.gdb")
        tempGdb2 = os.path.join(self.tempDir, "tempGDB2.gdb")
        tempGdb3 = os.path.join(self.tempDir, "tempGDB3.gdb")

        inProjection = GeneralFunctions.getProjection(inLines)
        projUnits = GeneralFunctions.translateLinearUnit(inProjection.linearUnitName)
        arcpy.env.workspace = self.evalGdb
        arcpy.env.overwriteOutput = True
        straightLinesName = nhdOrEdh + "_SS_Straights"
        segLinesName = nhdOrEdh + "_SS_Segments"
        straightLines = os.path.join(tempGdb1, straightLinesName)
        segLines = os.path.join(tempGdb2, segLinesName)

        #build temp straight lines
        GeneralFunctions.messageUser("\t Creating Straight Lines Feature Class")
        arcpy.CreateFeatureclass_management(tempGdb1, straightLinesName, geometry_type="POLYLINE", spatial_reference = inProjection)
        arcpy.AddField_management(straightLines, "OrigLineID", "SHORT")
        arcpy.AddField_management(straightLines, "SegID", "TEXT")

        #build temp seg lines
        GeneralFunctions.messageUser("\t Creating Segmented Lines Feature Class")
        arcpy.CreateFeatureclass_management(tempGdb2, segLinesName, geometry_type="POLYLINE", spatial_reference = inProjection)
        arcpy.AddField_management(segLines, "OrigLineID", "SHORT")
        arcpy.AddField_management(segLines, "SegID", "TEXT")
        arcpy.AddField_management(segLines, "SegLength", "DOUBLE")
        arcpy.AddField_management(segLines, "StraightLength", "DOUBLE")
        arcpy.AddField_management(segLines, "SegSin", "DOUBLE")
        arcpy.AddField_management(segLines, "SegSinW", "DOUBLE")

        #define cursors for searching through original lines, and inserting straight lines, and segments
        GeneralFunctions.messageUser("\t Building Cursors")
        lineCursor = arcpy.da.SearchCursor(inLines, ["OBJECTID", "Shape@"], where_clause = "FCode <> 55800")
        straightCursor = arcpy.da.InsertCursor(straightLines, ["OrigLineID","Shape@", "SegID"])
        segCursor = arcpy.da.InsertCursor(segLines, ["OrigLineID","Shape@", "SegID"])
        strLenDict = {}

        #try:
        GeneralFunctions.messageUser("\t Reading Lines and Building Segments")
        for feature in lineCursor:

            #get current line's OBJECTID
            lineObjectID = feature[0]
            partnum = 0

            # Step through each part of the line feature (accounts for multi-part features
            for linePart in feature[1]:

                thisLine = arcpy.Polyline(linePart, inProjection)

                #get first point
                firstPt = thisLine.firstPoint

                #get last point
                lastPt = thisLine.lastPoint

                #get seg breaks
                lineLength = thisLine.getLength("PLANAR",projUnits)
                positions = int(round(lineLength))
                posCount = int(round(segDist))
                posIteration = 1
                ptArray = arcpy.Array()
                ptArray.append(firstPt)

                #build segmented array
                for pos in range(0, positions, posCount):

                    #segment ID to serve as unique segment identifier
                    segIdSeg = str(lineObjectID) + "-" + str(posIteration)

                    #get segmented positions along line
                    splitHere = posCount
                    segSplit = splitHere*posIteration
                    posSplitGeo = thisLine.positionAlongLine(segSplit)
                    posSplitPt = posSplitGeo.firstPoint
                    ptArray.append(posSplitPt)

                    #build and insert seg line
                    if posIteration == 1:
                        startMes = 0
                        endMes = segSplit

                    elif not(posSplitPt.equals(lastPt)):
                        startMes = segSplit - splitHere
                        endMes = segSplit

                    else:
                        startMes = segSplit - splitHere
                        endMes = thisLine.length

                    #insert segment if it is greater than or equal to segDist
                    if startMes <> endMes:
                        lineSeg = thisLine.segmentAlongLine(startMes, endMes)
                        segRow = [lineObjectID, lineSeg, segIdSeg]
                        segCursor.insertRow(segRow)

                    posIteration+=1

                ptArray.append(lastPt)

                #build and insert straight line
                stIteration = 0
                for pt in ptArray:
                    if not(pt.equals(lastPt)):

                        #build straight line
                        thisArray = arcpy.Array()
                        thisArray.add(pt)
                        nextPtPos = stIteration + 1
                        thisArray.add(ptArray.getObject(nextPtPos))
                        strLine = arcpy.Polyline(thisArray, inProjection)
                        segIdSt = str(lineObjectID) + "-" + str(nextPtPos)

                        #add straight line length to dict to calculate straight line distance back to segments
                        strLength = strLine.length
                        strLenDict[segIdSt] = strLength

                        #insert straight line
                        srow = [lineObjectID, strLine, segIdSt]
                        straightCursor.insertRow(srow)
                        stIteration +=1

        #calculate spatial indices
        GeneralFunctions.messageUser("\t Calculating indices")
        arcpy.AddSpatialIndex_management(straightLines)
        arcpy.AddSpatialIndex_management(segLines)
        del lineCursor, straightCursor

        #copy seg lines to temp location
        GeneralFunctions.messageUser("\t Copying seg lines")
        segLinesCopy = os.path.join(tempGdb3, segLinesName + "_copy")
        arcpy.Copy_management(segLines, segLinesCopy)

        #join straight length to seglines, calculate sinuosity
        GeneralFunctions.messageUser("\t Performing Sinuosity Calculation...")
        segUCursor = arcpy.da.UpdateCursor(segLinesCopy, ["Shape@LENGTH", "SegID", "SegLength", "StraightLength", "SegSin", "OrigLineID","SegSinW"])
        for seg in segUCursor:

            myId = seg[1]
            myLen = seg[0]
            #attain straight line distance of corresponding line
            myStrLen = strLenDict[myId]
            mySegSin = myLen/myStrLen

            #new values
            seg[2] = myLen
            seg[3] = myStrLen
            seg[4] = mySegSin
            seg[6] = myLen * mySegSin

            #update row
            segUCursor.updateRow(seg)

        del segUCursor


        #Copy in Seg Data
        GeneralFunctions.messageUser("\t Copying in Final Segmented Sinuosity Data")
        segLinesFinal = os.path.join(self.evalGdb, segLinesName)
        straightLinesFinal = os.path.join(self.evalGdb, straightLinesName)

        arcpy.Copy_management(segLinesCopy, segLinesFinal)
        arcpy.Copy_management(straightLines, straightLinesFinal)


        #summarize sinuosity by feature and join back to original lines
        GeneralFunctions.messageUser("\t Calculating Sinuosity Stats")
        tableName1 = nhdOrEdh + "_SegSinStats1"
        tableName2 = nhdOrEdh + "_SegSinStats2"
        tableOut1 = os.path.join(tempGdb3, tableName1)
        tableOut2 = os.path.join(tempGdb3, tableName2)

        #weighted mean
        arcpy.Statistics_analysis(segLinesFinal, tableOut1, statistics_fields="SegSinW SUM;SegLength SUM", case_field="OrigLineID")
        arcpy.AddField_management(tableOut1, "WMEAN_SegSin", "DOUBLE")
        arcpy.CalculateField_management(tableOut1, field="WMEAN_SegSin", expression="!SUM_SegSinW!/ !SUM_SegLength!", expression_type="PYTHON_9.3", code_block="")

        #min, max, stdv of seg sin of lines within 10 percent of user's specified length
        lowBound = segDist * 0.9
        highBound = segDist * 1.1
        sqlBounds = 'SegLength BETWEEN ' + str(lowBound) + " AND " + str(highBound)
        boundName = nhdOrEdh + "_SegLinesLong"
        boundOut = os.path.join(tempGdb3, boundName)
        arcpy.Select_analysis(segLinesFinal, boundOut, sqlBounds)
        arcpy.Statistics_analysis(boundOut, tableOut2, statistics_fields="SegSin MIN;SegSin MAX;SegSin STD", case_field="OrigLineID")

        #join stats to original lines
        GeneralFunctions.messageUser("\t Joining Sinuosity Stats to line features")
        arcpy.JoinField_management(inLines, "OBJECTID", tableOut1, "OrigLineID", fields="WMEAN_SegSin")
        arcpy.JoinField_management(inLines, "OBJECTID", tableOut2, "OrigLineID", fields="MIN_SegSin;MAX_SegSin;STD_SegSin")



    def detect_EDHStraightSegs(self, segDist):
        '''Detects line segments that do not change bearining within segDist.'''

        edhProj = GeneralFunctions.getProjection(self.edhLines)

        #create straight segments feature class
        tempGDB3 = os.path.join(self.tempDir, "tempGDB3.gdb")
        straightSegs = os.path.join(tempGDB3, "EDH_StraightSegs")
        if arcpy.Exists(straightSegs):
            GeneralFunctions.messageUser("\t Deleting Old Straight Segments")
            arcpy.Delete_management(straightSegs)
        GeneralFunctions.messageUser("\t Creating Temporary Straight Segment Feature Class")
        arcpy.CreateFeatureclass_management(tempGDB3, "EDH_StraightSegs", geometry_type="POLYLINE", spatial_reference = edhProj)
        arcpy.AddField_management(straightSegs, "EDH_LineID", "LONG")

        #search through line features and detect straight segments. Insert straight segments into straight segment feature class
        GeneralFunctions.messageUser("\t Searching Through Line Features to Find Straight Segments")
        lineCursor = arcpy.da.SearchCursor(self.edhLines, ["OBJECTID", "Shape@"], where_clause = "FCode <> 55800 AND FCode <> 33600")
        stCursor = arcpy.da.InsertCursor(straightSegs, ["EDH_LineID","Shape@"])
        for line in lineCursor:
            origLine = line[0]
            detLine = GeneralFunctions.detectStraightSegs(line, segDist, edhProj)
            myFlags = detLine[0]
            myStLines = detLine[1]
            if myFlags>0:
                for ln in myStLines:
                    stCursor.insertRow([origLine, ln])

        del stCursor, lineCursor

        #add spatial index
        GeneralFunctions.messageUser("\t Straight Segment Search Complete")
        GeneralFunctions.messageUser("\t Adding Spatial Index")
        arcpy.AddSpatialIndex_management(straightSegs)

        #copy to eval gdb
        GeneralFunctions.messageUser("\t Copying Straight Segments to Evaluation Database")
        finalStraights = os.path.join(self.evalGdb, "EDH_StraightSegments")
        if arcpy.Exists(finalStraights):
            GeneralFunctions.messageUser("\t Removing old straight segments")
            arcpy.Delete_management(finalStraights)
        arcpy.Copy_management(straightSegs,finalStraights)

        #summarize straight segments per EDH line
        GeneralFunctions.messageUser("\t Calculating Summary Statistics for Straight Segments")
        straightSum = os.path.join(tempGDB3, "straightSum")
        arcpy.Statistics_analysis(in_table=finalStraights, out_table=straightSum, statistics_fields="Shape_Length SUM", case_field="EDH_LineID")

        #add intuitive fields to summary table
        arcpy.AddField_management(straightSum, "StraightSegCount", "LONG")
        arcpy.AddField_management(straightSum, "StraightSegSumLength", "DOUBLE")
        arcpy.CalculateField_management(in_table=straightSum, field="StraightSegCount", expression="!FREQUENCY!", expression_type="PYTHON_9.3", code_block="")
        arcpy.CalculateField_management(in_table=straightSum, field="StraightSegSumLength", expression="!SUM_Shape_Length!", expression_type="PYTHON_9.3", code_block="")

        #join summary fields to EDH lines
        GeneralFunctions.messageUser("\t Joining Summary Stats to EDH Lines")
        arcpy.JoinField_management(self.edhLines, in_field="OBJECTID", join_table=straightSum, join_field="EDH_LineID", fields="StraightSegCount;StraightSegSumLength")

    def detect_edhInitiationNearRoads(self, roadsFeatureClass, nearDist):
        '''Detects EDH_Lines that start near (within nearDist) roads (roadsFeatureClass).'''

        arcpy.env.workspace = self.evalGdb
        arcpy.env.overwriteOutput = True

        #get temp GDB
        tempGDB3 = os.path.join(self.tempDir, "tempGDB3.gdb")

        #create dangle points
        GeneralFunctions.messageUser("\t Creating Dangle Points")
        dangPoints = os.path.join(tempGDB3, "EDH_DanglePts")
        arcpy.FeatureVerticesToPoints_management(self.edhLines,dangPoints, "DANGLE")

        #select dangle points representing flowlines, these are stream headwaters
        GeneralFunctions.messageUser("\t Creating Flowline Headwater Points")
        fcodeFilter = "FCode <> 55800 AND FCode <> 33600"
        hwPoints = os.path.join(tempGDB3, "EDH_HwPoints")
        arcpy.Select_analysis(dangPoints,hwPoints, fcodeFilter)

        #determine roads projection, project if needed
        edhProj = GeneralFunctions.getProjection(self.edhLines)
        rdsProj = GeneralFunctions.getProjection(roadsFeatureClass)
        if edhProj.name != rdsProj.name:
            GeneralFunctions.messageUser("\t Projecting Roads")
            rdsForAnalysis = os.path.join(tempGDB3, "ProjectedRoads")
            arcpy.Project_management(roadsFeatureClass, rdsForAnalysis, edhProj)
        else:
            rdsForAnalysis = roadsFeatureClass

        #use near tool to find closeby roads
        GeneralFunctions.messageUser("\t Searching Headwaters for Nearby Roads")
        nearUnit = GeneralFunctions.translateLinearUnit(edhProj.linearUnitName)
        nearDistUnit = str(nearDist) + " " + nearUnit
        arcpy.Near_analysis(hwPoints, rdsForAnalysis, search_radius=nearDistUnit, location="NO_LOCATION", angle="NO_ANGLE", method="PLANAR")

        #select EDH vertices that are too close
        hwNearRds = os.path.join(tempGDB3, "HWNearRds")
        selExp="NEAR_FID <> -1"
        arcpy.Select_analysis(hwPoints, hwNearRds, where_clause=selExp)

        #create intuitive field name and join  to edh lines
        arcpy.AddField_management(hwNearRds, "HwProximityToRoad", "DOUBLE")
        arcpy.CalculateField_management(hwNearRds, "HwProximityToRoad", expression="!NEAR_DIST!", expression_type="PYTHON_9.3", code_block="")
        arcpy.JoinField_management(self.edhLines, in_field="OrigEDH_ID", join_table=hwNearRds, join_field="OrigEDH_ID", fields="HwProximityToRoad")


    def detect_closeVertices(self, nearDist=1.5):
        '''Detects EDH_Line vertices within nearDist.'''

        arcpy.env.workspace = self.evalGdb
        arcpy.env.overwriteOutput = True

        tempGDB2 = os.path.join(self.tempDir, "tempGDB2.gdb")
        edhLineVerts = os.path.join(tempGDB2, "EDH_LineVerts")

        #create line verts if they don't exist in eval gdb
        if not(arcpy.Exists(edhLineVerts)):
            GeneralFunctions.messageUser("\t Creating EDH Line Vertex Points")
            arcpy.FeatureVerticesToPoints_management(self.edhLines,edhLineVerts, "ALL")

        #use Near tool to find EDH vertices that are too close
        GeneralFunctions.messageUser("\t Searching for Vertices that are Too Close")
        inProj = GeneralFunctions.getProjection(self.edhLines)
        nearUnit = GeneralFunctions.translateLinearUnit(inProj.linearUnitName)
        nearDistUnit = str(nearDist) + " " + nearUnit
        arcpy.Near_analysis(edhLineVerts, edhLineVerts, search_radius=nearDistUnit, location="LOCATION", angle="NO_ANGLE", method="PLANAR")

        #select EDH vertices that are too close
        GeneralFunctions.messageUser("\t Selecting Vertices that are Too Close")
        selExp = "(NEAR_FID > 1) AND ( NEAR_DIST > 0 and NEAR_DIST <= 1)"
        flagVertsName = "EDH_LineVertsTooClose"
        flagVerts = os.path.join(self.evalGdb, flagVertsName)
        if arcpy.Exists(flagVerts):
            GeneralFunctions.messageUser("\t Removing old " + flagVertsName)
            arcpy.Delete_management(flagVerts)
        GeneralFunctions.messageUser("\t Creating " + flagVertsName)
        arcpy.Select_analysis(edhLineVerts, flagVerts, selExp)

        #flag EDH lines containing the vertices that are too close
        countVerts = arcpy.GetCount_management(flagVerts)
        if countVerts > 0:
            GeneralFunctions.messageUser("\t Joining Vertex Proximity Statistics to EDH Lines")
            cvSum = os.path.join(tempGDB2, "nearVerticesSummary")
            arcpy.Statistics_analysis(flagVerts, cvSum, statistics_fields="ORIG_FID COUNT", case_field="ORIG_FID")
            arcpy.AddField_management(cvSum, "VertsTooClose", "LONG")
            arcpy.CalculateField_management(cvSum, "VertsTooClose", expression="!COUNT_ORIG_FID!", expression_type="PYTHON_9.3", code_block="")
            arcpy.JoinField_management(self.edhLines, in_field="OBJECTID", join_table=cvSum, join_field="ORIG_FID", fields="VertsTooClose")

        return countVerts

    def detect_unintegratedVertices(self, dem, distThreshold = 1):
        '''Detects EDH_Line vertices that are beyond distThreshold from dem cell value.'''

        if arcpy.CheckExtension('Spatial') == u'Available':
            arcpy.CheckOutExtension('Spatial')

        arcpy.env.workspace = self.evalGdb
        arcpy.env.overwriteOutput = True

        tempGDB2 = os.path.join(self.tempDir, "tempGDB2.gdb")
        edhLineVerts = os.path.join(tempGDB2, "EDH_LineVerts")

        #create line verts if they don't exist in eval gdb
        if not(arcpy.Exists(edhLineVerts)):
            GeneralFunctions.messageUser("\t Creating EDH Line Vertex Points")
            arcpy.FeatureVerticesToPoints_management(self.edhLines,edhLineVerts, "ALL")

        #add fields for calculation
        GeneralFunctions.messageUser("\t Adding fields")
        arcpy.AddField_management(edhLineVerts,"POINT_Z", "DOUBLE")
        arcpy.AddField_management(edhLineVerts,"z_diff", "DOUBLE")
        arcpy.AddField_management(edhLineVerts,"z_diff_abs", "DOUBLE")

        #calculate Z Value to field
        GeneralFunctions.messageUser("\t Calculating Z Value to Field")
        arcpy.CalculateField_management(edhLineVerts, field="POINT_Z", expression="!shape.centroid.z!", expression_type="PYTHON_9.3", code_block="")

        #get DEM elevation value at point location
        GeneralFunctions.messageUser("\t Determining Z Value of DEM at Point XY")
        lineVertsDem = os.path.join(tempGDB2, "EDH_LineVertsDEM")
        arcpy.sa.ExtractValuesToPoints(edhLineVerts, dem,lineVertsDem)

        #calculate difference in Z value and absoloute Z value difference
        GeneralFunctions.messageUser("\t Calculating Difference")
        arcpy.CalculateField_management(lineVertsDem, field="z_diff", expression="!RASTERVALU! - !POINT_Z!", expression_type="PYTHON_9.3", code_block="")
        arcpy.CalculateField_management(lineVertsDem, field="z_diff_abs", expression="abs(!z_diff!)", expression_type="PYTHON_9.3", code_block="")

        #get vertices with value difference greater than flagging distance
        lineVertsDemSig = os.path.join(self.evalGdb, "EDH_UnintegratedVerts")
        flagExp = "z_diff_abs >=" + str(distThreshold)
        arcpy.Select_analysis(lineVertsDem, lineVertsDemSig, where_clause=flagExp)

        #build statistical tables
        GeneralFunctions.messageUser("\t Calculating Statistics per EDH Line")
        zCompTable = os.path.join(tempGDB2, "zCompTable")
        arcpy.Statistics_analysis(lineVertsDemSig, zCompTable, "z_diff MAX;z_diff MIN;z_diff MEAN;Z_diff_abs MEAN;z_diff STD;Z_diff_abs STD", "ORIG_FID;FCode")

        #add & calc intuitive field to join to EDH lines
        GeneralFunctions.messageUser("\t Creating and Calculating Flag Field")
        arcpy.AddField_management(zCompTable, "vert_z_flag", "SHORT")
        arcpy.CalculateField_management(zCompTable, field="vert_z_flag", expression="!FREQUENCY!", expression_type="PYTHON_9.3", code_block="")

        #join fields to EDH lines
        GeneralFunctions.messageUser("\t Joining Fields to EDH Lines")
        arcpy.JoinField_management(self.edhLines, in_field="OBJECTID", join_table=zCompTable, join_field="ORIG_FID", fields="MAX_z_diff;MIN_z_diff;MEAN_z_diff;STD_z_diff;MEAN_z_diff_abs;STD_z_diff_abs;vert_z_flag")

        #select lines with outlier vertices and outlier segments
        GeneralFunctions.messageUser("\t Creating Outlier Feature Classes")
        linesOutlierVerts = os.path.join("EDH_Lines_VertZ_Outliers")
        linesOutlierSegs = os.path.join(self.evalGdb, "EDH_Lines_SegZ_Outliers")
        vertZexpr = "MIN_z_diff <-" +str(distThreshold) + " OR MAX_z_diff > " +str(distThreshold)
        segZexpr = "(MEAN_Z_diff  > " + str(distThreshold) + " OR MEAN_Z_diff < -" + str(distThreshold) + ") OR (STD_z_diff > " + str(distThreshold) +  " OR STD_z_diff < -" + str(distThreshold) + ")"
        fcodeFilter = "FCode <> 55800 AND FCode <> 33600"
        arcpy.Select_analysis(self.edhLines, linesOutlierVerts, vertZexpr)
        arcpy.Select_analysis(self.edhLines, linesOutlierSegs, segZexpr)


    def create_dpaGrid(self, gridSize):
        '''Creates polygonal grid encompassing EDH_Lines.'''

        arcpy.env.workspace = self.evalGdb
        arcpy.env.overwriteOutput = True
        tempGDB2 = os.path.join(self.tempDir, "tempGDB2.gdb")

        #get extent of EDH Lines
        edhDesc = arcpy.Describe(self.edhLines)
        fnExt = edhDesc.extent
        minX = fnExt.XMin
        minY = fnExt.YMin
        yOrient = minY + 10.0
        maxX = fnExt.XMax
        maxY = fnExt.YMax
        orgCoord = str(minX) + " " + str(minY)
        yOrCoord = str(minX) + " " + str(yOrient)
        cornCoord = str(maxX) + " " + str(maxY)
        edhProj = GeneralFunctions.getProjection(self.edhLines)

        #create grid
        GeneralFunctions.messageUser("\t Creating DPA Grid")
        outFn = os.path.join(self.evalGdb, "DPA_Grid")
        arcpy.CreateFishnet_management(out_feature_class=outFn, origin_coord=orgCoord, y_axis_coord=yOrCoord, cell_width=gridSize, cell_height=gridSize, number_rows="", number_columns="", corner_coord=cornCoord, labels="NO_LABELS", geometry_type="POLYGON")

        #project grid
        GeneralFunctions.messageUser("\t Defining DPA Grid Projection")
        arcpy.DefineProjection_management(outFn, edhProj)


    def calc_gridSegSinuosity(self, gridSize=5000, edhOrNhd = "EDH"):
        '''Intersects EDH_SS_Segments or NHD_SS_Segments with DPA grid.'''

        dpaGrid = os.path.join(self.evalGdb, "DPA_Grid")
        tempGDB1 = os.path.join(self.tempDir, "tempGDB1.gdb")

        if not(arcpy.Exists(dpaGrid)):
            self.create_dpaGrid(gridSize)

        #put some try/except in here!!!!
        if edhOrNhd == "EDH":
            inLines = os.path.join(self.evalGdb, "EDH_SS_Segments")
        elif edhOrNhd == "NHD":
            inLines = os.path.join(self.evalGdb, "NHD_SS_Segments")
        else:
            GeneralFunctions.messageUser("\t ERROR - NHD OR EDH NOT SPECIFIED")

        #intersect lines with dpa grid
        GeneralFunctions.messageUser("\t Intersecting DPA Grid and Hydro Lines")
        inFc = [inLines, dpaGrid]
        outLinesName = edhOrNhd + "_" +"segGridLines"
        outGridLines = os.path.join(tempGDB1, outLinesName)
        arcpy.Intersect_analysis(in_features=inFc, out_feature_class=outGridLines, join_attributes="ALL", cluster_tolerance="-1 Unknown", output_type="INPUT")

        #average segmented sinuosity
        GeneralFunctions.messageUser("\t Summarizing Segmented Sinuosity")
        sumTableName = edhOrNhd + "_" +"gridSummary"
        sumTable = os.path.join(tempGDB1, sumTableName)
        arcpy.Statistics_analysis(in_table=outGridLines, out_table=sumTable, statistics_fields="SegSinW SUM; SegLength SUM", case_field="FID_DPA_Grid")

        #add intuitive field names and calculate
        GeneralFunctions.messageUser("\t Adding Fields")
        meanField = edhOrNhd + "_" +"grid_wmeanSegSin"
        cntField = edhOrNhd + "_" +"segmentCount"
        sumFields = [meanField, cntField]
        arcpy.AddField_management(sumTable, meanField, "DOUBLE")
        arcpy.AddField_management(sumTable, cntField, "LONG")
        arcpy.CalculateField_management(sumTable, cntField, expression="!FREQUENCY!", expression_type="PYTHON_9.3", code_block="")
        arcpy.CalculateField_management(sumTable, meanField, expression="!SUM_SegSinW!/!SUM_SegLength!", expression_type="PYTHON_9.3", code_block="")

        #join fields
        GeneralFunctions.messageUser("\t Joining Summary Information to DPA Grid")
        sumFieldSep = ";".join(sumFields)
        arcpy.JoinField_management(in_data=dpaGrid, in_field="OID", join_table=sumTable, join_field="FID_DPA_Grid", fields=sumFieldSep)

    def compare_gridSegSinuosity(self):
        '''Compares segmented sinuosity within DPA_Grid.'''

        dpaGrid = os.path.join(self.evalGdb, "DPA_Grid")

        if arcpy.Exists(dpaGrid):
            dpaFields = [nm.name for nm in arcpy.ListFields(dpaGrid)]

            if ("EDH_grid_wmeanSegSin" in dpaFields) and ("NHD_grid_wmeanSegSin" in dpaFields):
                GeneralFunctions.messageUser("\t Comparing Gridded Segmented Sinuosity")
                arcpy.AddField_management(dpaGrid, "WSegSin_Difference", "DOUBLE")
                arcpy.CalculateField_management(dpaGrid, "WSegSin_Difference", expression="!EDH_grid_wmeanSegSin!- !NHD_grid_wmeanSegSin!", expression_type="PYTHON_9.3", code_block="")
            else:
                GeneralFunctions.messageUser("\t EDH_meanSegSin and/or NHD_meanSegSin Field is Missing from DPA_Grid")
        else:
            GeneralFunctions.messageUser("\t DPA_Grid Is Not Stored in Eval Geodatabase")
#Script Name:                   ResultsReporting.py
#Purpose:                       To create and write analytical results of EDH Evaluation tools.
#Author:                        Lucian Stewart, North Carolina State University, 04/05/2020

import os, arcpy, GeneralFunctions, shutil, datetime

class EvalReport:
    '''Evaluation Report class contains functions that perform simple statistics on EDH Evaluation tool outputs and writes them to report text file.'''

    def __init__(self, evalEnv, configDir):
        self.evalEnv = evalEnv
        self.configDir = configDir


    def report_calcSegSin(self, segDistAndUnit, edhOrNhd="EDH"):
        '''Reports basic statistics of calcSegSin.'''
        now = str(datetime.datetime.now())
        analysisMxd = os.path.join(self.evalEnv, "EDH_AnalysisResults.mxd")
        configMxd = os.path.join(self.configDir, "EDH_AnalysisResults.mxd")
        evalGDB = os.path.join(self.evalEnv, "EDH_Evaluation.gdb")
        edhLines = os.path.join(evalGDB, "EDH_Lines")
        reportFile = os.path.join(self.evalEnv, "EDH_EvalReport.txt")

        if edhOrNhd == "EDH":
            sumSegs = os.path.join(evalGDB, "EDH_SS_Segments")
        elif edhOrNhd == "NHD":
            sumSegs = os.path.join(evalGDB, "NHD_SS_Segments")
        else:
            GeneralFunctions.messageUser("ERROR REPORTING STATISTICS")

        GeneralFunctions.messageUser("\t Calculating Summary Statistics for Segmented Sinuosity")
        if not(os.path.exists(analysisMxd)):
            mapSref = GeneralFunctions.getProjection(edhLines)
            mapExtent = GeneralFunctions.getExtent(edhLines)
            copyAnalysisMxd(configMxd, self.evalEnv, mapSref, mapExtent)

        segDist = float(segDistAndUnit.split(" ")[0])
        lowBound = segDist * 0.9
        highBound = segDist * 1.1
        sqlBounds = 'SegLength BETWEEN ' + str(lowBound) + " AND " + str(highBound)
        segCursor = arcpy.da.SearchCursor(sumSegs, ['SegSin'], where_clause = sqlBounds)
        sinList = [seg[0] for seg in segCursor]
        maxSin = max(sinList)
        minSin = min(sinList)
        wsegCursor = arcpy.da.SearchCursor(sumSegs, ['SegSinW','SegLength'])
        wSinList = [wseg[0]/wseg[1] for wseg in wsegCursor]
        avSin = sum(wSinList)/len(sinList)
        del segCursor, wsegCursor

        GeneralFunctions.messageUser("\t Reporting Statistics")
        reportMessage = edhOrNhd + " SEGMENTED SINUOSITY REPORT " + now
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "SEGMENT BREAK DISTANCE: " + segDistAndUnit
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "\t AVEREAGE (LENGTH WEIGHTED) SEGMENTED SINUOSITY: "  + str(avSin)
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "\t MAXIMUM SEGMENTED SINUOSITY: "  + str(maxSin)
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "\t MINIMUM SEGMENTED SINUOSITY: "  + str(minSin)
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "\t SEE: "  + sumSegs
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "\t\t FIELDS: SegLength, StraightLength, SegSin"
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "\t SEE: "  + edhLines
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "\t\t FIELDS: WMEAN, MIN, MAX SegSin"
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "_________________________________________________________________________________\n"
        writeAnalysisResults(reportFile, reportMessage, newLine = True)


    def report_compGridSegSin(self, gridSizeAndUnit):
        '''Reports basic statistics of compGridSegSin.'''
        now = str(datetime.datetime.now())
        analysisMxd = os.path.join(self.evalEnv, "EDH_AnalysisResults.mxd")
        configMxd = os.path.join(self.configDir, "EDH_AnalysisResults.mxd")
        evalGDB = os.path.join(self.evalEnv, "EDH_Evaluation.gdb")
        compGrid = os.path.join(evalGDB, "DPA_Grid")
        reportFile = os.path.join(self.evalEnv, "EDH_EvalReport.txt")
        edhLines = os.path.join(evalGDB, "EDH_Lines")

        GeneralFunctions.messageUser("\t Calculating Summary Statistics for Gridded Segmented Sinuosity")
        if not(os.path.exists(analysisMxd)):
            mapSref = GeneralFunctions.getProjection(edhLines)
            mapExtent = GeneralFunctions.getExtent(edhLines)
            copyAnalysisMxd(configMxd, self.evalEnv, mapSref, mapExtent)

        gridCursorImp = arcpy.da.SearchCursor(compGrid, ['WSegSin_Difference'], where_clause = "WSegSin_Difference > 0")
        gridCellsImproved = len([grd[0] for grd in gridCursorImp])
        del gridCursorImp
        gridCursorNeg = arcpy.da.SearchCursor(compGrid, ['WSegSin_Difference'], where_clause = "WSegSin_Difference < 0")
        gridCellsNeg = len([grd[0] for grd in gridCursorNeg])
        del gridCursorNeg
        gridTotal = int(gridCellsImproved) + int(gridCellsNeg)

        if gridCellsImproved > 0:
            pctImp = round(100 * (float(gridCellsImproved) / float(gridTotal)), 3)
        else: pctImp = "N/A"

        GeneralFunctions.messageUser("\t Reporting Statistics")
        reportMessage = "GRIDDED SEGMENTED SINUOSITY COMPARISON REPORT " + now
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "GRID SIZE: " + gridSizeAndUnit
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "\t PERCENTAGE OF GRID CELLS WITH IMPROVED AVERAGE LENGTH-WEIGHTED SEGMENTED SINUOSITY IN EDH VS. NHD: "  + str(pctImp)
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "\t TOTAL GRID CELLS WITH BOTH NHD AND EDH LINES: "  + str(gridTotal)
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "\t GRID CELLS WITH HIGHER AVERAGE LENGTH-WEIGHTED SEGMENTED SINUOSITY IN EDH VS. NHD: "  + str(gridCellsImproved)
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "\t GRID CELLS WITH LOWER AVERAGE LENGTH-WEIGHTED SEGMENTED SINUOSITY IN EDH VS. NHD: "  + str(gridCellsNeg)
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "\t SEE: "  + compGrid
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "\t\t FIELDS: EDH_grid_wmeanSegSin, EDH_segmentCount, NHD_grid_wmeanSegSin, NHD_segmentCount, WSegSin_Difference"
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "_________________________________________________________________________________\n"
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        os.startfile(reportFile)

    def report_initNearRoad(self, searchRadiusAndUnit):
        '''Reports basic statistics of initNearRoad.'''
        now = str(datetime.datetime.now())
        analysisMxd = os.path.join(self.evalEnv, "EDH_AnalysisResults.mxd")
        configMxd = os.path.join(self.configDir, "EDH_AnalysisResults.mxd")
        evalGDB = os.path.join(self.evalEnv, "EDH_Evaluation.gdb")
        edhLines = os.path.join(evalGDB, "EDH_Lines")
        reportFile = os.path.join(self.evalEnv, "EDH_EvalReport.txt")

        GeneralFunctions.messageUser("\t Calculating Summary Statistics for Stream Initiation Near Roads")
        if not(os.path.exists(analysisMxd)):
            mapSref = GeneralFunctions.getProjection(edhLines)
            mapExtent = GeneralFunctions.getExtent(edhLines)
            copyAnalysisMxd(configMxd, self.evalEnv, mapSref, mapExtent)

        edhCursor = arcpy.da.SearchCursor(edhLines, ['HwProximityToRoad'], where_clause = "HwProximityToRoad > 0")
        hwCount = len([edh[0] for edh in edhCursor])
        del edhCursor

        GeneralFunctions.messageUser("\t Reporting Statistics")
        reportMessage = "HEADWATER PROXIMITY TO ROAD REPORT " + now
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "SEARCH RADIUS: " + searchRadiusAndUnit
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "\t EDH FLOWLINES NEAR ROADS: " + str(hwCount)
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "\t SEE: "  + edhLines
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "\t\t FIELD: HwProximityToRoad"
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "_________________________________________________________________________________\n"
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        os.startfile(reportFile)

    def report_detectStraightEDH(self, straightDist, straightUnit):
        '''Reports basic statistics of detectStraightEDH.'''
        now = str(datetime.datetime.now())
        analysisMxd = os.path.join(self.evalEnv, "EDH_AnalysisResults.mxd")
        configMxd = os.path.join(self.configDir, "EDH_AnalysisResults.mxd")
        evalGDB = os.path.join(self.evalEnv, "EDH_Evaluation.gdb")
        strLines = os.path.join(evalGDB, "EDH_StraightSegments")
        reportFile = os.path.join(self.evalEnv, "EDH_EvalReport.txt")
        edhLines = os.path.join(evalGDB, "EDH_Lines")

        GeneralFunctions.messageUser("\t Calculating Summary Statistics for EDH Straight Segment Detection")
        if not(os.path.exists(analysisMxd)):
            mapSref = GeneralFunctions.getProjection(edhLines)
            mapExtent = GeneralFunctions.getExtent(edhLines)
            copyAnalysisMxd(configMxd, self.evalEnv, mapSref, mapExtent)

        seg1 = straightDist * 1.0
        seg2 = straightDist * 2.0
        seg3 = straightDist * 3.0
        strCursor1 = arcpy.da.SearchCursor(strLines, ['EDH_LineID'], where_clause = "Shape_Length >= " + str(seg1))
        seg1Count = len([seg[0] for seg in strCursor1])
        del strCursor1
        strCursor2 = arcpy.da.SearchCursor(strLines, ['EDH_LineID'], where_clause = "Shape_Length >= " + str(seg2))
        seg2Count = len([seg[0] for seg in strCursor2])
        del strCursor2
        strCursor3 = arcpy.da.SearchCursor(strLines, ['EDH_LineID'], where_clause = "Shape_Length >= " + str(seg3))
        seg3Count = len([seg[0] for seg in strCursor3])
        del strCursor3

        stCursor = arcpy.da.SearchCursor(edhLines, ['StraightSegCount'], where_clause = "StraightSegCount IS NOT NULL")
        stCount = len([stSeg[0] for stSeg in stCursor])
        del stCursor

        flowCursor = arcpy.da.SearchCursor(edhLines, ['FCode'], where_clause = "FCode <> 55800 AND FCode <> 33600")
        flCount = len([seg[0] for seg in flowCursor])
        del flowCursor

        if stCount > 0:
            stPct = round(100.0 *(float(stCount) / float(flCount)),3)
        else: stPct = 0



        GeneralFunctions.messageUser("\t Reporting Statistics")
        reportMessage = "EDH STRAIGHT SEGMENT DETECTION REPORT " + now
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "FLAGGING LENGTH: " + str(straightDist) + " " + straightUnit
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "\t STRAIGHT SEGMENTS GREATER THAN: " + str(seg1) + " " + straightUnit + ": " + str(seg1Count)
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "\t STRAIGHT SEGMENTS GREATER THAN: " + str(seg2) + " " + straightUnit + ": " + str(seg2Count)
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "\t STRAIGHT SEGMENTS GREATER THAN: " + str(seg3) + " " + straightUnit + ": " + str(seg3Count)
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "\t PERCENTAGE OF EDH FLOW LINES WITH STRAIGHT SEGMENTS GREATER THAN: " + str(seg1) + " " + straightUnit + ": " + str(stPct)
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "\t SEE: "  + strLines
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "\t\t FIELDS: EDH_LineID, Shape_Length"
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "\t SEE: "  + edhLines
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "\t\t FIELDS: StraightSegCount, StraightSegSumLength"
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "_________________________________________________________________________________\n"
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        os.startfile(reportFile)

    def report_flagNearVerts(self, nearDistAndUnit):
        '''Reports basic statistics of flagNearVerts.'''
        now = str(datetime.datetime.now())
        analysisMxd = os.path.join(self.evalEnv, "EDH_AnalysisResults.mxd")
        configMxd = os.path.join(self.configDir, "EDH_AnalysisResults.mxd")
        evalGDB = os.path.join(self.evalEnv, "EDH_Evaluation.gdb")
        nearVerts = os.path.join(evalGDB, "EDH_LineVertsTooClose")
        reportFile = os.path.join(self.evalEnv, "EDH_EvalReport.txt")
        edhLines = os.path.join(evalGDB, "EDH_Lines")

        GeneralFunctions.messageUser("\t Calculating Summary Statistics for Near EDH Vertices")
        if not(os.path.exists(analysisMxd)):
            mapSref = GeneralFunctions.getProjection(edhLines)
            mapExtent = GeneralFunctions.getExtent(edhLines)
            copyAnalysisMxd(configMxd, self.evalEnv, mapSref, mapExtent)


        vertCursor = arcpy.da.SearchCursor(nearVerts, ['OrigEDH_ID'])
        vertCount = len([vert[0] for vert in vertCursor])
        del vertCursor

        edhCursor = arcpy.da.SearchCursor(edhLines, ['VertsTooClose'], where_clause = "VertsTooClose > 0")
        edhCount = len([edh[0] for edh in edhCursor])
        del edhCursor

        edhCursor2 = arcpy.da.SearchCursor(edhLines, ['VertsTooClose'])
        edhCount2 = len([edh2[0] for edh2 in edhCursor2])
        del edhCursor2

        if edhCount > 0:
            tcPct = round(100.0 *(float(edhCount) / float(edhCount2)),3)
        else: tcPct = 0

        GeneralFunctions.messageUser("\t Reporting Statistics")
        reportMessage = "EDH PROXIMATE VERTEX REPORT " + now
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "SEARCH RADIUS: " + nearDistAndUnit
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "\t VERTICES THAT ARE TOO CLOSE: " + str(vertCount)
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "\t PERCENTAGE OF EDH LINES WITH VERTICES THAT ARE TOO CLOSE: " + str(tcPct)
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "\t SEE: "  + nearVerts
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "\t SEE: "  + edhLines
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "\t\t FIELD: VertsTooClose"
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "_________________________________________________________________________________\n"
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        os.startfile(reportFile)

    def report_flagUnitVerts(self, flagDistAndUnit):
        '''Reports basic statistics of flagUnitVerts.'''
        now = str(datetime.datetime.now())
        analysisMxd = os.path.join(self.evalEnv, "EDH_AnalysisResults.mxd")
        configMxd = os.path.join(self.configDir, "EDH_AnalysisResults.mxd")
        evalGDB = os.path.join(self.evalEnv, "EDH_Evaluation.gdb")
        unintVerts = os.path.join(evalGDB, "EDH_UnintegratedVerts")
        reportFile = os.path.join(self.evalEnv, "EDH_EvalReport.txt")
        edhLines = os.path.join(evalGDB, "EDH_Lines")
        vertZLines = os.path.join(evalGDB, "EDH_Lines_VertZ_Outliers")
        segZLines = os.path.join(evalGDB, "EDH_Lines_SegZ_Outliers")

        GeneralFunctions.messageUser("\t Calculating Summary Statistics for Unintegrated Vertices")
        if not(os.path.exists(analysisMxd)):
            mapSref = GeneralFunctions.getProjection(edhLines)
            mapExtent = GeneralFunctions.getExtent(edhLines)
            copyAnalysisMxd(configMxd, self.evalEnv, mapSref, mapExtent)


        vertCursor = arcpy.da.SearchCursor(unintVerts, ['OrigEDH_ID'])
        vertCount = len([vert[0] for vert in vertCursor])
        del vertCursor

        vertZCursor = arcpy.da.SearchCursor(vertZLines, ['OrigEDH_ID'])
        vertZCount = len([vz[0] for vz in vertZCursor])
        del vertZCursor

        segZCursor = arcpy.da.SearchCursor(segZLines, ['OrigEDH_ID'])
        segZCount = len([sz[0] for sz in segZCursor])
        del segZCursor

        edhFCursor = arcpy.da.SearchCursor(edhLines, ['vert_z_flag'], where_clause = 'vert_z_flag IS NOT NULL')
        edhFCount = len([edh[0] for edh in edhFCursor])
        del edhFCursor

        edhCursor = arcpy.da.SearchCursor(edhLines, ['vert_z_flag'])
        edhCount = len([edh[0] for edh in edhCursor])
        del edhCursor

        if vertZCount > 0:
            vzPct = round(100.0 *(float(vertZCount) / float(edhCount)),3)
        else: vzPct = 0


        GeneralFunctions.messageUser("\t Reporting Statistics")
        reportMessage = "EDH UNINTEGRATED VERTEX REPORT " + now
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "Z FLAGGING DISTANCE: " + flagDistAndUnit
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "\t UNINTEGRATED VERTICES: " + str(vertCount)
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "\t EDH LINES WITH AT LEAST ONE UNINTEGRATED VERTEX: " + str(vertZCount)
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "\t PERCENTAGE OF EDH LINES WITH AT LEAST ONE UNINTEGRATED VERTEX: " + str(vzPct)
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "\t EDH LINES WITH VERTEX Z VALUES THAT ARE ON AVERAGE " + (flagDistAndUnit) + " FROM THE SURFACE: " + str(segZCount)
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "\t SEE: "  + unintVerts
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "\t SEE: "  + vertZLines
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "\t SEE: "  + segZLines
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "_________________________________________________________________________________\n"
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        os.startfile(reportFile)

    def report_matchNHDtoEDH(self, qualVerts, edhDistAndUnit):
        '''Reports basic statistics of matchNHDtoEDH.'''
        now = str(datetime.datetime.now())
        analysisMxd = os.path.join(self.evalEnv, "EDH_AnalysisResults.mxd")
        configMxd = os.path.join(self.configDir, "EDH_AnalysisResults.mxd")
        evalGDB = os.path.join(self.evalEnv, "EDH_Evaluation.gdb")
        reportFile = os.path.join(self.evalEnv, "EDH_EvalReport.txt")
        edhLines = os.path.join(evalGDB, "EDH_Lines")
        nhdLines = os.path.join(evalGDB, "NHD_Lines")

        GeneralFunctions.messageUser("\t Calculating Summary Statistics for NHD-EDH Line Matching Process")
        if not(os.path.exists(analysisMxd)):
            mapSref = GeneralFunctions.getProjection(edhLines)
            mapExtent = GeneralFunctions.getExtent(edhLines)
            copyAnalysisMxd(configMxd, self.evalEnv, mapSref, mapExtent)

        nhdCursor = arcpy.da.SearchCursor(nhdLines, ['OBJECTID'])
        totalCount = len([nhd[0] for nhd in nhdCursor])
        del nhdCursor

        matchCursor = arcpy.da.SearchCursor(nhdLines, ['MatchFlag'], where_clause = "MatchFlag = 0")
        matchCount = len([nhd[0] for nhd in matchCursor])
        del matchCursor

        noMatchCursor = arcpy.da.SearchCursor(nhdLines, ['MatchFlag'], where_clause = "MatchFlag = 1")
        noMatchCount = len([nhd[0] for nhd in noMatchCursor])
        del noMatchCursor

        apMatchCursor = arcpy.da.SearchCursor(nhdLines, ['MatchFlag'], where_clause = "MatchFlag = 2")
        apMatchCount = len([nhd[0] for nhd in apMatchCursor])
        del apMatchCursor

        nonAPMatchCursor = arcpy.da.SearchCursor(nhdLines, ['MatchFlag'], where_clause = "MatchFlag = 3")
        nonAPMatchCount = len([nhd[0] for nhd in nonAPMatchCursor])
        del nonAPMatchCursor

        matchPct = float(matchCount+apMatchCount+nonAPMatchCount)/float(totalCount)

        GeneralFunctions.messageUser("\t Reporting Statistics")
        reportMessage = "NHD/EDH MATCHING REPORT " + now
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "CANDIDATE VERTEX DISTANCE: " + str(qualVerts)
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "QUALIFYING VERTEX DISTANCE: " + edhDistAndUnit
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "\t TOTAL NHD LINES " + str(totalCount)
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "\t TOTAL UNMATCHED NHD LINES: " + str(noMatchCount)
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "\t TOTAL NHD FLOW LINES THAT ONLY MATCHED EDH FLOW LINES: " + str(matchCount)
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "\t TOTAL NHD ARTIFICIAL PATHS THAT MATCHED EDH FLOW LINES: " + str(apMatchCount)
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "\t TOTAL NHD FLOW LINES THAT MATCHED EDH ARTIFICIAL PATHS: " + str(nonAPMatchCount)
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "\t MATCH PERCENTAGE: " + str(round(matchPct * 100, 2))
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "\t SEE: "  + nhdLines
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "\t\t FIELDS: EDH_LineIDs, MatchFlag"
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        reportMessage = "_________________________________________________________________________________\n"
        writeAnalysisResults(reportFile, reportMessage, newLine = True)
        os.startfile(reportFile)

def copyAnalysisMxd(mxdDoc, outLocation, spatialref, setExtent):
    '''Copies MXD map document file to user EDH Evaluation environment.'''

    #copy mxdDoc to outLocation
    mxdName = os.path.basename(mxdDoc)
    mxdDest = os.path.join(outLocation, mxdName)

    #update spatial reference and extent of mxd and save it
    mxdObject = arcpy.mapping.MapDocument(mxdDoc)
    df = arcpy.mapping.ListDataFrames(mxdObject)[0]
    df.spatialReference = spatialref
    newExtent = df.extent
    newExtent.XMin, newExtent.YMin = setExtent.XMin, setExtent.YMin
    newExtent.XMax, newExtent.YMax = setExtent.XMax, setExtent.YMax
    df.extent = newExtent

    mxdObject.save()
    shutil.copyfile(mxdDoc, mxdDest)

    return mxdDest

def writeAnalysisResults(resultsFile, resultMessage, newLine = True):
    '''Writes statements to results text file.'''
    myWrite = open(resultsFile, "a+")
    if newLine == True:
        myWrite.write("\n")
    myWrite.write(resultMessage)
    myWrite.close()
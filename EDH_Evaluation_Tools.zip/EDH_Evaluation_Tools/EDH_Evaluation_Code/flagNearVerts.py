#Script Name:                   flagNearVerts.py
#Corresponding Script Tool:     Flag Near Vertices
#Purpose:                       Detect EDH vertices that are within a user-specified distance.
#Methodology:                   Creates vertex point features of EDH_Lines and runs "Near" proximity tool to find vertices that are too close.
#                               Any line containing close vertices is flagged.  See "VertsTooClose" field of EDH_Lines.
#Author:                        Lucian Stewart, North Carolina State University, 04/05/2020

#import modules
import sys, os
thisPath = os.path.abspath(__file__)
thisDir = os.path.dirname(thisPath)
configPath = os.path.join(thisDir, "config")
sys.path.append(configPath)
import HydroAssessmentClass, GeneralFunctions, ResultsReporting
reload(HydroAssessmentClass)
reload(GeneralFunctions)
reload(ResultsReporting)



#get arguments
edhWS = sys.argv[1]
flagDist = float(sys.argv[2])
writeReport = sys.argv[3]
removeTemp = sys.argv[4]

#run analysis
myEvalGdb = os.path.join(edhWS, "EDH_Evaluation.gdb")
myTempWS = os.path.join(edhWS, "EDH_Assessment_TempDir")
myEDHLines = os.path.join(myEvalGdb, "EDH_Lines")
myFormattedEDH = HydroAssessmentClass.FormattedHydroData(myEvalGdb, myTempWS, myEDHLines)
myProj = GeneralFunctions.getProjection(myEDHLines)
myUnit = GeneralFunctions.translateLinearUnit(myProj.linearUnitName)
myDistUnit = str(flagDist) + " " + myUnit
GeneralFunctions.messageUser("Flagging vertices within " + myDistUnit)
myFormattedEDH.detect_closeVertices(flagDist)

#write report
if writeReport == "true":
    myReport = ResultsReporting.EvalReport(edhWS, configPath)
    myReport.report_flagNearVerts(myDistUnit)

if removeTemp == "true":
    GeneralFunctions.cleanTempGdbs(myTempWS)